# Bankkonto-Verwaltung

Dieses Java-Projekt ermöglicht das Anlegen und Verwalten von Bankkonten. Es unterstützt Girokonten und Sparkonten mit verschiedenen Funktionen wie Einzahlen, Auszahlen und Zinsberechnung.

## Features

- Konto anlegen (Girokonto oder Sparkonto)
- Kontoinformationen anzeigen
- Einzahlen und Auszahlen von Beträgen
- Zinsen berechnen (für Sparkonten einzeln oder alle Sparkonten)
- Alle Konten anzeigen
- Konto löschen mit Bestätigung
- Konsolenbasiertes Menü zur einfachen Bedienung

## Projektstruktur

- `Konto.java` - Basisklasse für Bankkonten
- `Girokonto.java` - Erweiterung von Konto mit Dispolimit
- `Sparkonto.java` - Erweiterung von Konto mit Zinssatz und Zinsberechnung
- `BankVerwaltung.java` (oder wie deine Hauptklasse heißt) - Hauptklasse mit Benutzerinterface und Kontoverwaltung

## Voraussetzungen

- Java Development Kit (JDK) 11 oder höher
- IDE oder Terminal zum Kompilieren und Ausführen

## Nutzung

1. Projekt kompilieren:
   ```bash
   javac *.java